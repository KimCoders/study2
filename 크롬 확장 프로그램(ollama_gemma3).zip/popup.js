document.getElementById("send-button").addEventListener("click", () => {
    const userInput = document.getElementById("user-input").value;
    const responseElement = document.getElementById("response");

    if (!userInput.trim()) {
        responseElement.textContent = "질문을 입력해주세요.";
        return;
    }

    responseElement.textContent = "로딩 중...";

    chrome.runtime.sendMessage(
        { action: "queryOllama", prompt: userInput },
        (response) => {
            if (response && response.success) {
                responseElement.textContent = response.response || "응답이 없습니다.";
            } else {
                responseElement.textContent = "오류 발생: " + (response?.error || "알 수 없는 오류");
            }
        }
    );
});