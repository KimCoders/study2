chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "queryOllama") {
        (async () => {
            try {
                const response = await fetch("http://localhost:3000/api/generate", { // 프록시 서버로 요청
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ model: "gemma3:12b", prompt: request.prompt })
                });

                if (!response.ok) {
                    throw new Error(`HTTP 오류: ${response.status}`);
                }

                const data = await response.json();
                sendResponse({ success: true, response: data.response });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();

        return true; // 비동기 응답을 기다리기 위해 필요
    }
});