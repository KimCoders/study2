﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Net.Http;
using System.Text.Json; // nuget 에서 설치
using System.Speech.Synthesis; // nuget 에서 설치


namespace ChatBot_Test1
{
    public partial class Form1 : Form
    {
        // http클라이언트 
        private HttpClient httpClient;
        // TTS를 사용 하기 위해 Speech 생성
        SpeechSynthesizer synth = new SpeechSynthesizer();

        public Form1()
        {
            InitializeComponent();
            // httpClient
            httpClient = new HttpClient();
            // 보이스 음성 설정
            synth.SelectVoice("Microsoft Heami Desktop");
        }


        private async void button1_Click(object sender, EventArgs e)
        {
            textBox2.Text = "답변 생성중...";

            // URL 설정
            string url = "http://localhost:11434/api/generate";
            // 보낼 json 데이터 만들기 
            string model = comboBox2.Text;
            string prompt = textBox1.Text;

            var jsonObject = new
            {
                model,
                prompt,
                stream = false
            };

            // json 방식으로 string 만들기
            string jsonInput = JsonSerializer.Serialize(jsonObject);

            // 인코딩 설정 
            var content = new StringContent(jsonInput, Encoding.UTF8, "application/json");

            try
            {
                // 비동기로 API 호출
                HttpResponseMessage response = await httpClient.PostAsync(url, content);
                
                // 응답 성공시 처리
                if(response.IsSuccessStatusCode)
                {
                    // 비동기로 답변 받기
                    string responseContent = await response.Content.ReadAsStringAsync();

                    // JSON 파싱
                    JsonDocument doc = JsonDocument.Parse(responseContent);
                    JsonElement root = doc.RootElement;

                    // "response" 필드 값 추출
                    if (root.TryGetProperty("response", out JsonElement responseElement))
                    {
                        // 필드 값 만 추출
                        string responseText = responseElement.GetString();

                        // 답변 들어갈 텍스트 박스 초기화
                        textBox2.Text = "";

                        // 답변에 줄바꿈 문자가 있으면 한줄씩 배열에 잘라 넣는다.
                        string[] responseDataMake = responseText.Split('\n');

                        // foreach를 이용해서 줄바꿈 텍스트 병합
                        foreach (string s in responseDataMake)
                        {
                            // 답변에 텍스트 나열
                            textBox2.Text += s + "\r\n";
                        }

                        // TTS 출력
                        if(checkBox1.Checked)
                            TTS(textBox2.Text);
                    }
                }
                else
                {
                    textBox2.Text = "답변을 받을 수 없습니다.";
                }
            }
            catch(System.Threading.Tasks.TaskCanceledException)
            {
                label3.Text = "Log : TaskCanceledException";
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //httpClient.Dispose();
            //base.OnFormClosed(e);
        }

        public void TTS(string msg)
        {
            // 보이스 음성 설정 (사용자가 변경 했을 경우)
            synth.SelectVoice(comboBox1.Text);
            // 기존에 비동기로 나오던 음성이 있으면 모두 중단
            synth.SpeakAsyncCancelAll();
            // 새로운 메세지를 받아 Speech로 출력
            synth.SpeakAsync(msg);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1.Checked)
            {
                foreach(var TTS_List in synth.GetInstalledVoices())
                {
                    comboBox1.Items.Add(TTS_List.VoiceInfo.Name.ToString());
                }

                if (comboBox1.Items.Count > 0)
                    comboBox1.SelectedIndex = 0;
            }
        }
    }
}
